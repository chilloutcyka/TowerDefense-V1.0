
public class Values {
	public static int groundGrass = 0;
	public static int airAir = -1;
	
}
